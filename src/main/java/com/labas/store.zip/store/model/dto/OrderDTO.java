package com.labas.store.model.dto;public class OrderDTO {
}
