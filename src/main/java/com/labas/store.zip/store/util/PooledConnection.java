package com.labas.store.util;


import java.sql.Connection;

public class PooledConnection implements AutoCloseable {

    private Connection connnection;
    private ConnectionPool pool;

    PooledConnection(Connection connection, ConnectionPool pool) {
        this.connnection = connection;
        this.pool = pool;
    }

    @Override
    public void close() {
        pool.releaseConnection(connnection);
    }
}
