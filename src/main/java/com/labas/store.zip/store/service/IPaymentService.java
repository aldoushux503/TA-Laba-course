package com.labas.store.service;

import com.labas.store.model.entity.Payment;

public interface IPaymentService extends IGenericService<Payment, Long> {
}
