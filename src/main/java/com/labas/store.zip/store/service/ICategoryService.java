package com.labas.store.service;

import com.labas.store.model.entity.Category;

public interface ICategoryService extends IGenericService<Category, Long> {
}
