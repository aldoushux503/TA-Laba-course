package com.labas.store.service;

import com.labas.store.model.entity.OrderStatus;

public interface IOrderStatusService extends IGenericService<OrderStatus, Long> {
}
