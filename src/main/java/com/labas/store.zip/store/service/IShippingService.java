package com.labas.store.service;

import com.labas.store.model.entity.Shipping;

public interface IShippingService extends IGenericService<Shipping, Long> {
}
