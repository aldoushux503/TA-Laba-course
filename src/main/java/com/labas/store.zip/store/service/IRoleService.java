package com.labas.store.service;

import com.labas.store.model.entity.Role;

public interface IRoleService extends IGenericService<Role, Long> {
}
