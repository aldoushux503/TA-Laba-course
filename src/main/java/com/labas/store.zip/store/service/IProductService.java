package com.labas.store.service;

import com.labas.store.model.entity.Product;

public interface IProductService extends IGenericService<Product, Long> {
}
