package com.labas.store.service;

import com.labas.store.model.entity.User;

public interface IUserService extends IGenericService<User, Long> {
}
