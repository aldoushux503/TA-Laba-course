package com.labas.store.service;

import com.labas.store.model.entity.Order;

public interface IOrderService extends IGenericService<Order, Long> {
}
